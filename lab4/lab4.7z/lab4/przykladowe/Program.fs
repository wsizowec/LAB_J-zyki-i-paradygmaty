﻿// For more information see https://aka.ms/fsharp-console-apps
printfn "Hello from F#"
let x=10
let text = "Jan"
let y = 10.3
printfn "Wartosc X = %d" x
printfn "Wartosc y = %f" y
printfn "Tekst = %s" text

printfn "Podaj imię: "
let name = System.Console.ReadLine()
printfn "Witaj, %s" name
let powitanie = "Witaj" + " Jan"


open System

let xy = 5
if xy > 0 then
    printfn "Liczba dodatnia"
else
    printfn "Liczba ujemna"



for i = 1 to 5 do
    printfn "Wartość %d" i

for i = 5 downto 1 do
    printfn "Wartość %d" i

let mutable xz = 5
while xz<5 do
    printfn "Wartość %d" xz
    xz <- xz+1

type Osoba =
    {
        Imie: string
        Wiek: int
    }

let osoba1 = {Imie = "Jan"; Wiek = 24}
printfn "Imie: %s, Wiek: %d" osoba1.Imie osoba1.Wiek

let rec suma n = 
    if n<= 0 then 0
    else n + suma(n-1)


//rekurencja ogonowa
let sumRekTail n =
    let rec loop n acc =
        if n <= 0 then acc
        else loop (n-1) (acc+n) // rekurencja ogonowa
    loop n 0 //wywolanie funkcji pomocniczej