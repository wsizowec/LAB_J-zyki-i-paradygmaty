﻿open System


type UserInfo = {
    Weight: float 
    Height: float 
}

let calculateBMI (weight: float) (height: float) =
    weight / (height * height)

let getBMICategory (bmi: float) =
    if bmi < 18.5 then "Niedowaga"
    elif bmi < 24.9 then "Prawidłowa masa ciała"
    elif bmi < 29.9 then "Nadwaga"
    else "Otyłość"

[<EntryPoint>]
let main argv =
    printfn "Podaj wagę (kg):"
    let weight = Console.ReadLine() |> float

    printfn "Podaj wzrost (cm):"
    let heightInCm = Console.ReadLine() |> float
    let heightInMeters = heightInCm / 100.0 

    let bmi = calculateBMI weight heightInMeters

    let category = getBMICategory bmi

    printfn "Twoje BMI wynosi %.2f i należy do kategorii: %s" bmi category

    0 
