﻿open System

type Konto = {
    NumerKonta: string
    mutable Saldo: float
}

let mutable konta = Map.empty<string, Konto>

let tworzenieKonta numerKonta =
    if konta.ContainsKey(numerKonta) then
        printfn "Konto o podanym numerze już istnieje."
    else
        let noweKonto = { NumerKonta = numerKonta; Saldo = 0.0 }
        konta <- konta.Add(numerKonta, noweKonto)
        printfn "Konto %s zostało utworzone." numerKonta

let depozyt numerKonta kwota =
    match konta.TryFind(numerKonta) with
    | Some konto when kwota > 0.0 ->
        konto.Saldo <- konto.Saldo + kwota
        printfn "Depozyt %.2f PLN na konto %s został wykonany." kwota numerKonta
    | Some _ when kwota <= 0.0 ->
        printfn "Kwota depozytu musi być większa od 0."
    | None ->
        printfn "Konto nie istnieje."

let wyplata numerKonta kwota =
    match konta.TryFind(numerKonta) with
    | Some konto when kwota > 0.0 && konto.Saldo >= kwota ->
        konto.Saldo <- konto.Saldo - kwota
        printfn "Wypłata %.2f PLN z konta %s została wykonana." kwota numerKonta
    | Some _ when kwota <= 0.0 ->
        printfn "Kwota wypłaty musi być większa od 0."
    | Some konto when konto.Saldo < kwota ->
        printfn "Niewystarczające środki na koncie."
    | None ->
        printfn "Konto nie istnieje."

let wyswietlSaldo numerKonta =
    match konta.TryFind(numerKonta) with
    | Some konto ->
        printfn "Saldo konta %s: %.2f PLN" numerKonta konto.Saldo
    | None ->
        printfn "Konto nie istnieje."

let rec menu () =
    printfn "\nMenu:"
    printfn "1. Utwórz nowe konto"
    printfn "2. Depozyt"
    printfn "3. Wypłata"
    printfn "4. Wyświetl saldo"
    printfn "5. Wyjście"
    
    let wybor = Console.ReadLine()
    
    match wybor with
    | "1" ->
        printfn "Podaj numer konta:"
        let numerKonta = Console.ReadLine()
        tworzenieKonta numerKonta
        menu()
    | "2" ->
        printfn "Podaj numer konta:"
        let numerKonta = Console.ReadLine()
        printfn "Podaj kwotę depozytu:"
        let kwota = float (Console.ReadLine())
        depozyt numerKonta kwota
        menu()
    | "3" ->
        printfn "Podaj numer konta:"
        let numerKonta = Console.ReadLine()
        printfn "Podaj kwotę wypłaty:"
        let kwota = float (Console.ReadLine())
        wyplata numerKonta kwota
        menu()
    | "4" ->
        printfn "Podaj numer konta:"
        let numerKonta = Console.ReadLine()
        wyswietlSaldo numerKonta
        menu()
    | "5" ->
        printfn "Dziękujemy za skorzystanie z aplikacji!"
    | _ ->
        printfn "Nieprawidłowa opcja. Spróbuj ponownie."
        menu()

[<EntryPoint>]
let main argv =
    menu()
    0
