﻿open System

let exchangeRates = 
    Map [
        ("USD", 1.0) 
        ("UAH", 41.3) 
        ("GBP", 0.78)  
        ("PLN", 4.15) 
    ]

let convertCurrency amount sourceCurrency targetCurrency =
    match exchangeRates.TryFind sourceCurrency, exchangeRates.TryFind targetCurrency with
    | Some rateFrom, Some rateTo ->

        let amountInUSD = amount / rateFrom
        let convertedAmount = amountInUSD * rateTo
        Some convertedAmount
    | _ -> None  

[<EntryPoint>]
let main argv =
    printfn "Podaj kwotę do konwertacji:"
    let amount = Console.ReadLine() |> float

    printfn "Podaj walutę którą wymieniasz (USD, UAH, GBP, PLN):"
    let sourceCurrency = Console.ReadLine().ToUpper()

    printfn "Podaj walutę na jaką wymieniasz (USD, UAH, GBP, PLN):"
    let targetCurrency = Console.ReadLine().ToUpper()

    match convertCurrency amount sourceCurrency targetCurrency with
    | Some convertedAmount ->
        printfn "Kwota %.2f %s zostaje przeliczona na %.2f %s" amount sourceCurrency convertedAmount targetCurrency
    | None ->
        printfn "Nieprawidłowa waluta lub kurs wymiany nie jest dostępny."

    0
